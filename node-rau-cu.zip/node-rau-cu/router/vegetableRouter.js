const express = require('express');
const {
  getVegetables,
  addVegetable,
  updateVegetable,
  deleteVegetable
} = require('../vegetableAPI');

const router = express.Router();

// Route: Trang chủ - hiển thị danh sách rau củ
router.get('/', async (req, res) => {
  try {
    const vegetables = await getVegetables(1); // Trang đầu tiên
    res.render('index', { vegetables });
  } catch (err) {
    console.error('Lỗi API:', err.message);
    res.render('index', { vegetables: [] });
  }
});

// Route: Thêm rau củ mới
router.post('/add', async (req, res) => {
  const { name, price, group, description } = req.body;
  const newVegetable = { name, price, group, description };

  try {
    await addVegetable(newVegetable);
    res.redirect('/');
  } catch (err) {
    console.error('Lỗi khi thêm rau củ:', err.message);
    res.redirect('/');
  }
});

// Route: Hiển thị form chỉnh sửa rau củ
router.get('/edit/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const vegetables = await getVegetables(1); // Lấy danh sách rau củ
    const vegetable = vegetables.find(v => String(v.id) === id); // So sánh ID

    if (vegetable) {
      res.render('edit', { vegetable });
    } else {
      res.redirect('/');
    }
  } catch (err) {
    console.error('Lỗi khi lấy thông tin rau củ:', err.message);
    res.redirect('/');
  }
});

// Route: Cập nhật rau củ
router.post('/edit/:id', async (req, res) => {
  const { id } = req.params;
  const { price, description } = req.body;

  try {
    await updateVegetable(id, price, description);
    res.redirect('/');
  } catch (err) {
    console.error('Lỗi khi cập nhật rau củ:', err.message);
    res.redirect('/');
  }
});

// Route: Xóa rau củ
router.post('/delete/:id', async (req, res) => {
  const { id } = req.params;

  try {
    await deleteVegetable(id);
    res.redirect('/');
  } catch (err) {
    console.error('Lỗi khi xóa rau củ:', err.message);
    res.redirect('/');
  }
});

module.exports = router;
